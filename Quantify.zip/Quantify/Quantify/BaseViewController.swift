//
//  BaseViewController.swift
//  Quantify
//
//  Created by Amy Dowse on 26/03/2021.
//

import UIKit

class BaseViewController: UIViewController
{
    var screenRect = UIScreen.main.bounds
    var screenWidth = CGFloat()
    var screenHeight = CGFloat()
    
    var buttonBackground = UIColor(red: 25/255, green: 56/255, blue: 209/255, alpha: 1.0)
    var buttonText = UIColor.white
    var buttonBoarderSize = 0.25
    var buttonBoarderColour = UIColor.white
    
    @IBOutlet weak var quantifyButton: UIButton!
    @IBOutlet weak var tasksButton: UIButton!
    @IBOutlet weak var contactsButton: UIButton!
    @IBOutlet weak var settingsButton: UIButton!
    
    
    override func viewDidLoad()
    {
        screenWidth = screenRect.size.width
        screenHeight = screenRect.size.height
        
        setButtons(button: quantifyButton)
        setButtons(button: tasksButton)
        setButtons(button: contactsButton)
        setButtons(button: settingsButton)
        
        if(UserDefaults.standard.bool(forKey: "AlreadyExists"))
        {
            quantifyPressed((Any).self)
        }
        else
        {
            tasksPressed((Any).self)
        }
        

    }
    
    @IBAction func tasksPressed(_ sender: Any) {
        
        let controller = storyboard!.instantiateViewController(withIdentifier: "TasksViewController")
        addChild(controller)
        controller.view.frame = CGRect(x:0, y: 0, width:screenWidth, height:(screenHeight - ((1/7.41) * screenHeight)))
        view.addSubview(controller.view)
        controller.didMove(toParent: self)
    }
    
    
    
    @IBAction func quantifyPressed(_ sender: Any) {
        let controller = storyboard!.instantiateViewController(withIdentifier: "QuantifyViewController")
        addChild(controller)
        controller.view.frame = CGRect(x:0, y: 0, width:screenWidth, height:(screenHeight - ((1/7.41) * screenHeight)))
        view.addSubview(controller.view)
        controller.didMove(toParent: self)
    }
    
    @IBAction func contactsPressed(_ sender: Any) {
        let controller = storyboard!.instantiateViewController(withIdentifier: "UserViewController")
        addChild(controller)
        controller.view.frame = CGRect(x:0, y: 0, width:screenWidth, height:(screenHeight - ((1/7.41) * screenHeight)))
        view.addSubview(controller.view)
        controller.didMove(toParent: self)
    }
    
    
    @IBAction func settingsPressed(_ sender: Any) {
        let controller = storyboard!.instantiateViewController(withIdentifier: "SettingsViewController")
        addChild(controller)
        controller.view.frame = CGRect(x:0, y: 0, width:screenWidth, height:(screenHeight - ((1/7.41) * screenHeight)))
        view.addSubview(controller.view)
        controller.didMove(toParent: self)
    }
 
    
    func setButtons(button:UIButton)
    {
        button.layer.backgroundColor = buttonBackground.cgColor
        button.layer.borderWidth = CGFloat(buttonBoarderSize)
        button.layer.borderColor = buttonBoarderColour.cgColor
        button.setTitleColor(buttonText, for: .normal)
    }
    
    
    
    
}

