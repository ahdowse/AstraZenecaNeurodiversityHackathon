//
//  ViewController.swift
//  Quantify
//
//  Created by Amy Dowse on 26/03/2021.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var txtCode1: UITextField!
    @IBOutlet weak var txtCode2: UITextField!
    @IBOutlet weak var txtCode3: UITextField!
    @IBOutlet weak var txtCode4: UITextField!
    @IBOutlet weak var lblIncorrect: UILabel!
    

    //Setting up so that number keyboard visible when clicking on each textbox
    override func viewDidLoad()
    {
        super.viewDidLoad()
        lblIncorrect.isHidden=true
        self.txtCode1.keyboardType = UIKeyboardType.numberPad
        self.txtCode2.keyboardType = UIKeyboardType.numberPad
        self.txtCode3.keyboardType = UIKeyboardType.numberPad
        self.txtCode4.keyboardType = UIKeyboardType.numberPad
       
        txtCode1.becomeFirstResponder()
        UserDefaults.standard.set(false, forKey: "AlreadyExists")
        //incorrectLabel.isHidden = true
    }
    
   

    
    @IBAction func logInPressed(_ sender: Any)
    {
    
        
        let enteredPasscode = txtCode1.text! + txtCode2.text! + txtCode3.text! + txtCode4.text!
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Security")
        
        do
        {
            let information = try managedContext.fetch(fetchRequest)
         
            
            if(information[0].value(forKey: "passcode") as! String == enteredPasscode)
            {
                lblIncorrect.isHidden = true
                let controller = storyboard!.instantiateViewController(withIdentifier: "BaseViewController") as! BaseViewController
                addChild(controller)
                view.addSubview(controller.view)
                controller.didMove(toParent: self)
            }
            else
            {
                txtCode1.text = ""
                txtCode2.text = ""
                txtCode3.text = ""
                txtCode4.text = ""
                txtCode1.becomeFirstResponder()
                lblIncorrect.isHidden = false
            }
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
    }
    
    
    //Methods to move along to the next textbox when something is entered 
    
    @IBAction func code1Changed(_ sender: Any)
    {
        txtCode1.isSecureTextEntry = false
        if((txtCode1.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.txtCode1.isSecureTextEntry = true
            }
            txtCode2.becomeFirstResponder()
            txtCode1.resignFirstResponder()
            
        }
    }
    
    @IBAction func code2Changed(_ sender: Any)
    {
        txtCode2.isSecureTextEntry = false
        if((txtCode2.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.txtCode2.isSecureTextEntry = true
            }
            txtCode3.becomeFirstResponder()
            txtCode2.resignFirstResponder()
        }
    }
    
    @IBAction func code3Changed(_ sender: Any)
    {
        txtCode3.isSecureTextEntry = false
        if((txtCode3.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.txtCode3.isSecureTextEntry = true
            }
            txtCode4.becomeFirstResponder()
            txtCode3.resignFirstResponder()
        }
    }
    
    @IBAction func code4Changed(_ sender: Any)
    {
        txtCode4.isSecureTextEntry = false
        if((txtCode4.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.txtCode4.isSecureTextEntry = true
            }
            
            txtCode4.resignFirstResponder()
        }
    }
    
    
    
    func createStartingValues()
    {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        do
        {
            let entity = NSEntityDescription.entity(forEntityName: "QuantifyElements", in: managedContext)!
            let element1 = NSManagedObject(entity: entity, insertInto: managedContext)
            let element2 = NSManagedObject(entity: entity, insertInto: managedContext)
            let element3 = NSManagedObject(entity: entity, insertInto: managedContext)
            let element4 = NSManagedObject(entity: entity, insertInto: managedContext)
            
            element1.setValue(1, forKeyPath: "quantifyIndex")
            element1.setValue("Urgency", forKeyPath: "quantifyName")
            
            element2.setValue(2, forKeyPath: "quantifyIndex")
            element2.setValue("Depth", forKeyPath: "quantifyName")
            
            element3.setValue(3, forKeyPath: "quantifyIndex")
            element3.setValue("Length", forKeyPath: "quantifyName")
            
            element4.setValue(4, forKeyPath: "quantifyIndex")
            element4.setValue("Importance", forKeyPath: "quantifyName")
    
            
            
            let entity2 = NSEntityDescription.entity(forEntityName: "Task", in: managedContext)!
            let task1 = NSManagedObject(entity: entity2, insertInto: managedContext)
            let task2 = NSManagedObject(entity: entity2, insertInto: managedContext)
            let task3 = NSManagedObject(entity: entity2, insertInto: managedContext)
            
            task1.setValue(1, forKeyPath: "taskIndex")
            task1.setValue("Paper", forKeyPath: "taskTitle")
            task1.setValue("Write a research paper", forKeyPath: "taskDescription")
            task1.setValue("In progress", forKeyPath: "taskStatus")
            
            task2.setValue(2, forKeyPath: "taskIndex")
            task2.setValue("Interviews", forKeyPath: "taskTitle")
            task2.setValue("Do those interviews of people", forKeyPath: "taskDescription")
            task2.setValue("In progress", forKeyPath: "taskStatus")
            
            task3.setValue(3, forKeyPath: "taskIndex")
            task3.setValue("User Guide", forKeyPath: "taskTitle")
            task3.setValue("Write a user guide for that really cool things", forKeyPath: "taskDescription")
            task3.setValue("Completed", forKeyPath: "taskStatus")
            
        
            try managedContext.save()
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        print("DONE")

    }
}
