//
//  TasksViewController.swift
//  Quantify
//
//  Created by Amy Dowse on 26/03/2021.
//


import UIKit
import CoreData

class TasksViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource
{

    @IBOutlet weak var changeView: UIPickerView!
    @IBOutlet weak var taskView: UICollectionView!
    
    var tasksArray = [TaskObject]()
    var pickerData: [String] = [String]()
    var selection:String = "Waiting"
    private var doubleTapGesture: UITapGestureRecognizer!
    
    override func viewDidLoad()
    {
        retrieveInformation(option: selection)
        setUpDoubleTap()
        self.changeView.delegate = self
        self.changeView.dataSource = self
        pickerData = ["All", "Waiting", "In Progress", "Completed"]
                        //Waiting = waiting to get things quantified
                        //In progress = working on the project
                        //Completed = finished project
                        //All = shows all categories of projects
        UserDefaults.standard.set(false, forKey: "AlreadyExists")
    }
    
    
    //Set up that the action is single tap on the scrollable section
    //Initially created with double tap but changed later in process- therefore names are still as double tap
    func setUpDoubleTap()
    {
        doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(didDoubleTapCollectionView))
        doubleTapGesture.numberOfTapsRequired = 2
        taskView.addGestureRecognizer(doubleTapGesture)
        doubleTapGesture.delaysTouchesBegan = true
    }
    
    //Determining which item in the view was tapped
    @objc func didDoubleTapCollectionView()
    {
        let pointInCollectionView = doubleTapGesture.location(in: taskView)
        if let selectedIndexPath = taskView.indexPathForItem(at: pointInCollectionView)
        {
            UserDefaults.standard.set(tasksArray[selectedIndexPath.row].taskIndex, forKey: "Key")
            
            let controller = storyboard!.instantiateViewController(withIdentifier: "SingleTaskViewController") as! SingleTaskViewController
            addChild(controller)
            view.addSubview(controller.view)
            controller.didMove(toParent: self)
        }
    }
    
    
    
    //The picker to select which tasks to show
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    // Capture the picker view selection
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        selection = pickerData[row]
        retrieveInformation(option: selection)
        
        var interimArray = [TaskObject]()
        
        if(pickerData[row] == "All")
        {
            taskView.reloadData()
        }
        
        if(pickerData[row] == "In Progress")
        {
            for item in tasksArray
            {
                if(item.taskStatus == "In Progress")
                {
                    interimArray.append(item)
                }
            }
        
            tasksArray = interimArray
            taskView.reloadData()
        }
        
        if(pickerData[row] == "Completed")
        {
            for item in tasksArray
            {
                if(item.taskStatus == "Completed")
                {
                    interimArray.append(item)
                }
            }
        
            tasksArray = interimArray
            taskView.reloadData()

        }
        
        if(pickerData[row] == "Waiting")
        {
            for item in tasksArray
            {
                if(item.taskStatus == "Waiting")
                {
                    interimArray.append(item)
                }
            }
        
            tasksArray = interimArray
            taskView.reloadData()

        }
    }

    
    
    
    
    //The list view 
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return tasksArray.count
    }
    
    //Sets what information is to be shown in each cell
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TaskCollectionViewCell", for: indexPath) as! TaskCollectionViewCell
        
        print(tasksArray[indexPath.row].taskTitle)
        
        cell.lblTitle.text = tasksArray[indexPath.row].taskTitle
        cell.lblDetails.text = String(tasksArray[indexPath.row].taskDescription)
        
        if(tasksArray[indexPath.row].taskStatus == "Waiting")
        {
            cell.imgStatus.image = UIImage(named: "Waiting.png")
        }
        else if (tasksArray[indexPath.row].taskStatus == "In Progress")
        {
            cell.imgStatus.image = UIImage(named: "InProgress.png")
        }
        else
        {
            cell.imgStatus.image = UIImage(named: "Done.png")
        }
        
        
        return cell
    }
    
  
    
    
    
    
    
    
    
    
    //Gets the tasks information from core data
    func retrieveInformation(option: String)
    {
        tasksArray.removeAll()
        
        //Work done to get the saved items
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
    
        //Populating the tasks array
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Task")
        do
        {
            let tasks = try managedContext.fetch(fetchRequest)
            for oneTask in tasks
            {
                let x = TaskObject(titleIn: oneTask.value(forKey: "taskTitle")as! String, descriptionIn: oneTask.value(forKey: "taskDescription")as! String, statusIn: oneTask.value(forKey: "taskStatus")as! String, indexIn: oneTask.value(forKey: "taskIndex")as! Int64)
            
                tasksArray.append(x)
            }
            
            
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
    }
    
    
    
    
    
    
    
    
}

