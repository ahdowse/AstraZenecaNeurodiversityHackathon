//
//  SettingsCollectionViewCell.swift
//  Quantify
//
//  Created by Amy Dowse on 30/03/2021.
//

import Foundation
import UIKit

class SettingsCollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var lblTitle: UILabel!
    
}
