//
//  TaskCollectionViewCell.swift
//  Quantify
//
//  Created by Amy Dowse on 26/03/2021.
//

import Foundation
import UIKit

class TaskCollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDetails: UILabel!
    @IBOutlet weak var imgStatus: UIImageView!
}
