//
//  QuantifyViewController.swift
//  Quantify
//
//  Created by Amy Dowse on 26/03/2021.
//

import UIKit
import CoreData
import MessageUI

class QuantifyViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, MFMailComposeViewControllerDelegate
{
    @IBOutlet weak var txtTaskName: UITextField!
    @IBOutlet weak var txtTaskDescription: UITextView!
    @IBOutlet weak var quantifyCollectionView: UICollectionView!
    
    private var doubleTapGesture: UITapGestureRecognizer!
    
    var quantifyArray: [String] = [String]()
    var selectedQuantifyArray: [Bool] = [Bool]()
    
    
    override func viewDidLoad()
    {
        retrieveInformation()
        selectedQuantifyArray = [Bool](repeating: false, count: quantifyArray.count)
        setUpDoubleTap()
        
        if(UserDefaults.standard.bool(forKey: "AlreadyExists"))
        {
            retrieveSavedInformation()
            selectedQuantifyArray = [Bool](repeating: false, count: quantifyArray.count)
            updateSelectedQuantify()
        }
        
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(clickOff))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
        
        print(UserDefaults.standard.bool(forKey: "AlreadyExists"))
    }
    
    //Set up that the action is single tap on the scrollable section
    //Initially created with double tap but changed later in process- therefore names are still as double tap
    func setUpDoubleTap()
    {
        doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(didDoubleTapCollectionView))
        doubleTapGesture.numberOfTapsRequired = 1
        quantifyCollectionView.addGestureRecognizer(doubleTapGesture)
        doubleTapGesture.delaysTouchesBegan = true
    }
    
    //Hides keyboard and moves view down to fill whole screen
    @objc func clickOff()
    {
        view.endEditing(true)
    }
    
    //Determining which item in the view was tapped
    @objc func didDoubleTapCollectionView()
    {
        let pointInCollectionView = doubleTapGesture.location(in: quantifyCollectionView)
        if let selectedIndexPath = quantifyCollectionView.indexPathForItem(at: pointInCollectionView)
        {
            if(selectedQuantifyArray[selectedIndexPath.row] == true)
            {
                selectedQuantifyArray[selectedIndexPath.row] = false
                self.quantifyCollectionView.reloadData()
            }
            else
            {
                selectedQuantifyArray[selectedIndexPath.row] = true
                self.quantifyCollectionView.reloadData()
            }
            
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return quantifyArray.count
    }
    
    
    //Sets what information is to be shown in each cell
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "QuantifyCollectionViewCell", for: indexPath) as! QuantifyCollectionViewCell
        
        cell.lblTitle.text = quantifyArray[indexPath.row]
        
        if(selectedQuantifyArray[indexPath.row]==true)
        {
            cell.imgSelection.image = UIImage(named: "FullCircle.png")
        }
        else
        {
            cell.imgSelection.image = UIImage(named: "EmptyCircle.png")
        }
        
        return cell
    }
    
    
    @IBAction func btnCreate(_ sender: Any)
    {
        if(txtTaskName.text != "")
        {
            var list = ""
            let sequence = zip(selectedQuantifyArray, quantifyArray)

            for (selected, element) in sequence
            {
                if(selected == true)
                {
                    list = list + "- " + element + "<br/>"
                }
            }
                
            var message = "<p>Hi,</p><p> I am working on the " + txtTaskName.text! + " and there are a few elements that I need some more clarification on. Please could you quantify the following elements of the project:</p>" + list + "<p>Thank you for your help.</p>"
                
                
                saveTask()
                saveElements()
                sendEmail(message: message, taskName: txtTaskName.text!)
        
        }
        else
        {
            var alert = UIAlertController(title: "ERROR", message: "Please include a task name", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func sendEmail(message:String, taskName:String)
    {
        if MFMailComposeViewController.canSendMail()
        {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setSubject("Quantify: " + taskName)
            mail.setMessageBody(message, isHTML: true)

            present(mail, animated: true)
        } else {
            // show failure alert
        }
    }

    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
    
    
    
    
    //Gets the list of the quantifiable elements
    func retrieveInformation()
    {
        quantifyArray.removeAll()
        
        //Work done to get the saved items
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
    
        //Populating the tasks array
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "QuantifyElements")
        do
        {
            let elements = try managedContext.fetch(fetchRequest)
            for oneElement in elements
            {
                quantifyArray.append(oneElement.value(forKey: "QuantifyName")as! String)
            }
            
            quantifyArray.sort()
            
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
    }
    
    
    //Gets information about the task if it has already been made
    func retrieveSavedInformation()
    {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
    
        //Populating the tasks array
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Task")
        do
        {
            let tasks = try managedContext.fetch(fetchRequest)
            for oneTask in tasks
            {
                if(oneTask.value(forKey: "taskIndex")as! Int64 == Int64(UserDefaults.standard.string(forKey: "Key")!))
                {
                    txtTaskName.text = oneTask.value(forKey: "taskTitle")as? String
                    txtTaskDescription.text = oneTask.value(forKey: "taskDescription")as? String
                }
            }
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    
    //Get a list of all of the already selected quantifiable elements selected
    func updateSelectedQuantify()
    {
 
        var alreadySelected:[String]=[String]()
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
    
        //Populating the tasks array
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Details")
        do
        {
            let elements = try managedContext.fetch(fetchRequest)
            for element in elements
            {
                if(element.value(forKey: "taskIndex")as! Int64 == Int64(UserDefaults.standard.string(forKey: "Key")!))
                {
                    alreadySelected.append(element.value(forKey: "quantifyElement") as! String)
                }
            }
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        
        for item in alreadySelected
        {
            for index in 0..<quantifyArray.count
            {
                if(quantifyArray[index] == item)
                {
                    selectedQuantifyArray[index] = true
                    
                }
            }
        }
    }
    
    
    
    
    
    
    
    
    //Saves or updates the task information (name, description, index and status)
    func saveTask()
    {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        if(!UserDefaults.standard.bool(forKey: "AlreadyExists"))
        {
            let entity = NSEntityDescription.entity(forEntityName: "Task", in: managedContext)!
            let item = NSManagedObject(entity: entity, insertInto: managedContext)
            
            item.setValue(txtTaskName.text, forKeyPath: "taskTitle")
            item.setValue(txtTaskDescription.text, forKeyPath: "taskDescription")
            item.setValue("Waiting", forKeyPath: "taskStatus")
            item.setValue(getTaskIndex()+1, forKeyPath: "taskIndex")
            
            do
            {
                try managedContext.save()
            }
            catch let error as NSError
            {
                print("Could not save. \(error), \(error.userInfo)")
            }
        }
        else
        {
             let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Task")
             
             do
             {
                 let tasks = try managedContext.fetch(fetchRequest)
                 for task in tasks
                 {
                     if(task.value(forKey: "taskIndex") as! Int64 == Int64(UserDefaults.standard.string(forKey: "Key")!))
                     {
                        task.setValue(txtTaskName.text, forKey: "taskTitle")
                        task.setValue(txtTaskDescription.text, forKey: "taskDescription")
                        task.setValue("Waiting", forKey: "taskStatus")
                     }
                 }
                 try managedContext.save()
                 
             }
             catch let error as NSError
             {
                 print("Could not fetch. \(error), \(error.userInfo)")
             }
        }
        
    }
    
    
    
    
    
    
    
    
    
    
    
    func saveSingleQuantifyElement(taskIndex: Int64, quantifyElement:String, quantifyDetail:String)
    {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Details", in: managedContext)!
        let item = NSManagedObject(entity: entity, insertInto: managedContext)
        
        item.setValue(taskIndex, forKeyPath: "taskIndex")
        item.setValue(quantifyElement, forKeyPath: "quantifyElement")
        item.setValue(quantifyDetail, forKeyPath: "quantifyDetails")
        
        do
        {
            try managedContext.save()
        }
        catch let error as NSError
        {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    
    
    
    
    

    
    //Saves or updates the quantify elements
    func saveElements()
    {
        if(!UserDefaults.standard.bool(forKey: "AlreadyExists"))
        {
            print("IN THE BIT WHERE IT DOESNT ALREADY EXIST")
            let sequence = zip(selectedQuantifyArray, quantifyArray)
            for (selected, element) in sequence
            {
                if(selected == true)
                {
                    saveSingleQuantifyElement(taskIndex: Int64(getTaskIndex()), quantifyElement: element, quantifyDetail: "")
                }
            }
        }
        else
        {
            var selected = zip(quantifyArray,selectedQuantifyArray)
     
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate else {
                    return
            }
            
            let managedContext = appDelegate.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Details")
            
            do
            {
                let tasks = try managedContext.fetch(fetchRequest)
                
                //Removes the quantify details of things that are unselected
                for task in tasks
                {
                    if(task.value(forKey: "taskIndex") as! Int64 == Int64(UserDefaults.standard.string(forKey: "Key")!))
                    {
                        for (element, selection) in selected
                        {
                            if(task.value(forKey: "quantifyElement") as! String == element && !selection)
                            {
                                managedContext.delete(task as NSManagedObject)
                            }
                        }
                    }
                }
                
                
                //Adds in new things that are selected that aren't already there
                var found = false
                for (element, selection) in selected
                {
                    if (selection)
                    {
                        found = false
                        for task in tasks
                        {
                           
                            if(task.value(forKey: "quantifyElement")as! String == element)
                            {
                                found = true
                            }
                        }
                        if(found == false)
                        {
                            saveSingleQuantifyElement(taskIndex: Int64(UserDefaults.standard.string(forKey: "Key")!)!, quantifyElement: element, quantifyDetail: "")
                            found = false
                        }
                    }
                }
                
                try managedContext.save()
            }
            catch let error as NSError
            {
                print("Could not fetch. \(error), \(error.userInfo)")
            }
                 
             
        }
        
    }
    
    
    
    //Get the current max ID number of the tasks saved
    func getTaskIndex() -> Int
    {
        //Work done to get the saved items
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return 0
        }
    
        //Populating the tasks array
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Task")
        do
        {
            let elements = try managedContext.fetch(fetchRequest)
            var max = -1
            for oneElement in elements
            {
                if(oneElement.value(forKey: "taskIndex") as! Int > max)
                {
                    max = oneElement.value(forKey: "taskIndex") as! Int
                }
            }
            
            return max
            
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        return 0
    }
    
    
}

    
//Class the allows the index of the double tapped image to remove to be used to remove from tapped array
class MyTapGesture: UITapGestureRecognizer
{
    var index = -1
}






