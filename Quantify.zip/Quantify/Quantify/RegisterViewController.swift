//
//  RegisterViewController.swift
//  Quantify
//
//  Created by Amy Dowse on 30/03/2021.
//

import UIKit
import CoreData

class RegisterViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource
{
    @IBOutlet weak var questionPicker: UIPickerView!
    
    @IBOutlet weak var securityQuestion: UITextField!
    
    @IBOutlet weak var textBox1a: UITextField!
    @IBOutlet weak var textBox1b: UITextField!
    @IBOutlet weak var textBox1c: UITextField!
    @IBOutlet weak var textBox1d: UITextField!
    
    @IBOutlet weak var textBox2a: UITextField!
    @IBOutlet weak var textBox2b: UITextField!
    @IBOutlet weak var textBox2c: UITextField!
    @IBOutlet weak var textBox2d: UITextField!
    
    @IBOutlet weak var mismatchLabel: UILabel!
    
    var pickerData: [String] = [String]()
    var question = ""
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        pickerData = ["Please select a question:", "Name of first pet?", "Name of Primary School?", "Favourite subject at school?", "Favourite colour?", "Mothers maiden name?", "Day of the week you were born?"]
        
        questionPicker.delegate = self
        questionPicker.dataSource = self
        
        securityQuestion.autocorrectionType = .no
        securityQuestion.becomeFirstResponder()
        
        textBox1a.keyboardType = UIKeyboardType.numberPad
        textBox1b.keyboardType = UIKeyboardType.numberPad
        textBox1c.keyboardType = UIKeyboardType.numberPad
        textBox1d.keyboardType = UIKeyboardType.numberPad
        
        textBox2a.keyboardType = UIKeyboardType.numberPad
        textBox2b.keyboardType = UIKeyboardType.numberPad
        textBox2c.keyboardType = UIKeyboardType.numberPad
        textBox2d.keyboardType = UIKeyboardType.numberPad
        
        mismatchLabel.isHidden = true
        
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        question = pickerData[row]
    }
    
    
    //Checks if entered information is ok - all entered and passcodes match
    @IBAction func goPressed(_ sender: Any)
    {
        textBox2d.resignFirstResponder()
        
        let firstEntered = textBox1a.text! + textBox1b.text! + textBox1c.text! + textBox1d.text!
        let secondEntered = textBox2a.text! + textBox2b.text! + textBox2c.text! + textBox2d.text!
      
        if(firstEntered == secondEntered && firstEntered.count == 4 && secondEntered.count == 4 && securityQuestion.text!.count > 0 && question != "Please select a question:" && question != "")
        {
            mismatchLabel.isHidden = true
            save(passcode: firstEntered)
            createStartingValues()
        }
        else
        {
            mismatchLabel.isHidden = false
            textBox2a.text = ""
            textBox2b.text = ""
            textBox2c.text = ""
            textBox2d.text = ""
            textBox2a.becomeFirstResponder()
        }
    }
    
    //Creates the starting values for the gender and achievement scores (setting up information)
    func createStartingValues()
    {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        do
        {
            //Create a couple of started quantify elements
            let QuantifyElement = NSEntityDescription.entity(forEntityName: "QuantifyElements", in: managedContext)!
            let element = NSManagedObject(entity: QuantifyElement, insertInto: managedContext)
            element.setValue(1, forKeyPath: "quantifyIndex")
            element.setValue("Urgency", forKeyPath: "quantifyName")
            
            let element2 = NSManagedObject(entity: QuantifyElement, insertInto: managedContext)
            element2.setValue(2, forKeyPath: "quantifyIndex")
            element2.setValue("Depth", forKeyPath: "quantifyName")
        
            
            try managedContext.save()
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    
    
    //Saves the security question, answer and passcode and then changes screen to first screen
    func save(passcode: String)
    {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Security", in: managedContext)!
        let newData = NSManagedObject(entity: entity, insertInto: managedContext)
        
        newData.setValue(question, forKeyPath: "question")
        newData.setValue(securityQuestion.text, forKeyPath: "answer")
        newData.setValue(passcode, forKeyPath: "passcode")
        
        do
        {
            try managedContext.save()
        }
        catch let error as NSError
        {
            print("Could not save. \(error), \(error.userInfo)")
        }
        
        mismatchLabel.isHidden = true
        let controller = storyboard!.instantiateViewController(withIdentifier: "BaseViewController") as! BaseViewController
        addChild(controller)
        controller.view.frame = CGRect(x:0, y: 0, width:375, height:667)
        view.addSubview(controller.view)
        controller.didMove(toParent: self)
        
    }
    
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox1aEntered(_ sender: Any)
    {
        textBox1a.isSecureTextEntry = false
        if((textBox1a.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox1a.isSecureTextEntry = true
            }
            textBox1b.becomeFirstResponder()
            textBox1a.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox1bEntered(_ sender: Any)
    {
        textBox1b.isSecureTextEntry = false
        if((textBox1b.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox1b.isSecureTextEntry = true
            }
            textBox1c.becomeFirstResponder()
            textBox1b.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox1cEntered(_ sender: Any)
    {
        textBox1c.isSecureTextEntry = false
        if((textBox1c.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox1c.isSecureTextEntry = true
            }
            textBox1d.becomeFirstResponder()
            textBox1c.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox1dEntered(_ sender: Any)
    {
        textBox1d.isSecureTextEntry = false
        if((textBox1d.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox1d.isSecureTextEntry = true
            }
            textBox2a.becomeFirstResponder()
            textBox1d.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox2aEntered(_ sender: Any)
    {
        textBox2a.isSecureTextEntry = false
        if((textBox2a.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox2a.isSecureTextEntry = true
            }
            textBox2b.becomeFirstResponder()
            textBox2a.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox2bEntered(_ sender: Any)
    {
        textBox2b.isSecureTextEntry = false
        if((textBox2b.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox2b.isSecureTextEntry = true
            }
            textBox2c.becomeFirstResponder()
            textBox2b.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox2cEntered(_ sender: Any)
    {
        textBox2c.isSecureTextEntry = false
        if((textBox2c.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox2c.isSecureTextEntry = true
            }
            textBox2d.becomeFirstResponder()
            textBox2c.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox2dEntered(_ sender: Any)
    {
        textBox2d.isSecureTextEntry = false
        if((textBox2d.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox2d.isSecureTextEntry = true
            }
            
            
        }
    }
    
    
}
