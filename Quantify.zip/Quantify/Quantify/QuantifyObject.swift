//
//  QuantifyObject.swift
//  Quantify
//
//  Created by Amy Dowse on 30/03/2021.
//

import UIKit

class QuantifyObject
{
    var taskIndex: Int64
    var quantifyElement: String
    var quantifyData: String
    
    init(indexIn: Int64, elementIn: String, dataIn: String)
    {
        taskIndex = indexIn
        quantifyElement = elementIn
        quantifyData = dataIn
    }
    
}
