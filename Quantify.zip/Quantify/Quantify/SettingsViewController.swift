//
//  SettingsViewController.swift
//  Quantify
//
//  Created by Amy Dowse on 30/03/2021.
//

import Foundation
import UIKit
import CoreData


class SettingsViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource
{
    @IBOutlet weak var txtNewElement: UITextField!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var elementsArray:[String] = [String]()
    
    override func viewDidLoad()
    {
        retrieveInformaiton()
        UserDefaults.standard.set(false, forKey: "AlreadyExists")
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(clickOff))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }
    
    @objc func clickOff()
    {
        view.endEditing(true)
        self.view.frame.origin.y = 0
    }
    
    @IBAction func btnAdd(_ sender: Any)
    {
        if(txtNewElement.text != "")
        {
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate else {
                    return
            }
            
            let managedContext = appDelegate.persistentContainer.viewContext
            
            do
            {
                let entity = NSEntityDescription.entity(forEntityName: "QuantifyElements", in: managedContext)!
                let element1 = NSManagedObject(entity: entity, insertInto: managedContext)
                
                element1.setValue(getNextIndex(), forKeyPath: "quantifyIndex")
                element1.setValue(txtNewElement.text, forKeyPath: "quantifyName")
                
                try managedContext.save()
            }
            catch let error as NSError
            {
                print("Could not fetch. \(error), \(error.userInfo)")
            }
            
            txtNewElement.text = ""
            retrieveInformaiton()
            collectionView.reloadData()
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return elementsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SettingsCollectionViewCell", for: indexPath) as! SettingsCollectionViewCell
        
        cell.lblTitle.text = elementsArray[indexPath.row]
        
        return cell
    }
    
    func retrieveInformaiton()
    {
        elementsArray.removeAll()
        
        //Work done to get the saved items
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
    
        //Populating the tasks array
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "QuantifyElements")
        do
        {
            let elements = try managedContext.fetch(fetchRequest)
            for oneElement in elements
            {
                elementsArray.append(oneElement.value(forKey: "QuantifyName")as! String)
            }
            
            elementsArray.sort()
            
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    
    func getNextIndex() -> Int
    {
        //Work done to get the saved items
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return 0
        }
    
        //Populating the tasks array
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "QuantifyElements")
        do
        {
            let elements = try managedContext.fetch(fetchRequest)
            var max = -1
            for oneElement in elements
            {
                if(oneElement.value(forKey: "quantifyIndex") as! Int > max)
                {
                    max = oneElement.value(forKey: "quantifyIndex") as! Int
                }
            }
            
            return max+1
            
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        return 0
    }
}
