//
//  StartViewController.swift
//  Quantify
//
//  Created by Amy Dowse on 30/03/2021.
//

import UIKit
import CoreData

class Start:UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        if(isFirstLoad())
        {
            //Very first load - show the register screen
            let controller = storyboard!.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
            addChild(controller)
            view.addSubview(controller.view)
            controller.didMove(toParent: self)
        }
        else
        {
            //Subsequant load - show the login screen
            let controller = storyboard!.instantiateViewController(withIdentifier: "ViewController") as! ViewController
            addChild(controller)
            view.addSubview(controller.view)
            controller.didMove(toParent: self)
                    
        }
    }
    
    
    //Determines if this is the first every load of the app
    //  True = Register
    //  False = Login
    func isFirstLoad() -> Bool
    {
        var firstLoad = false
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return firstLoad
        }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Security")
        
        do
        {
            let information = try managedContext.fetch(fetchRequest)
            if(information.count == 0)
            {
                firstLoad = true
            }
            
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return firstLoad
    }
}
