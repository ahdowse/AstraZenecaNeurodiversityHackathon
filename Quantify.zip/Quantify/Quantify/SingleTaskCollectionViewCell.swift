//
//  SingleTaskCollectionViewCell.swift
//  Quantify
//
//  Created by Amy Dowse on 30/03/2021.
//

import Foundation
import UIKit

class SingleTaskCollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var lblQuantifyTitle: UILabel!
    
    @IBOutlet weak var txtQuantifyDetails: UITextField!
    
    
}
