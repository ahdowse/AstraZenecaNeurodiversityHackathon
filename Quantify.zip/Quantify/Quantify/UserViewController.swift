//
//  UserViewController.swift
//  Quantify
//
//  Created by Amy Dowse on 30/03/2021.
//

import UIKit
import CoreData

class UserViewController: UIViewController
{

    
    @IBOutlet weak var securityQuestionLabel: UILabel!
    @IBOutlet weak var securityQuestionAnswer: UITextField!
    
    @IBOutlet weak var incorrectInformation: UILabel!
    
    @IBOutlet weak var textBox1a: UITextField!
    @IBOutlet weak var textBox1b: UITextField!
    @IBOutlet weak var textBox1c: UITextField!
    @IBOutlet weak var textBox1d: UITextField!
    
    @IBOutlet weak var textBox2a: UITextField!
    @IBOutlet weak var textBox2b: UITextField!
    @IBOutlet weak var textBox2c: UITextField!
    @IBOutlet weak var textBox2d: UITextField!
    
    @IBOutlet weak var textBox3a: UITextField!
    @IBOutlet weak var textBox3b: UITextField!
    @IBOutlet weak var textBox3c: UITextField!
    @IBOutlet weak var textBox3d: UITextField!
    
   
    
    var question = "Name of first pet?"
    var answer = ""
    var passcode = ""
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
  
        retrieveInformation()
    
        securityQuestionLabel.text = question
        
        incorrectInformation.isHidden = true
    
        securityQuestionAnswer.autocorrectionType = .no
        
        textBox1a.keyboardType = UIKeyboardType.numberPad
        textBox1b.keyboardType = UIKeyboardType.numberPad
        textBox1c.keyboardType = UIKeyboardType.numberPad
        textBox1d.keyboardType = UIKeyboardType.numberPad
        
        textBox2a.keyboardType = UIKeyboardType.numberPad
        textBox2b.keyboardType = UIKeyboardType.numberPad
        textBox2c.keyboardType = UIKeyboardType.numberPad
        textBox2d.keyboardType = UIKeyboardType.numberPad
        
        textBox3a.keyboardType = UIKeyboardType.numberPad
        textBox3b.keyboardType = UIKeyboardType.numberPad
        textBox3c.keyboardType = UIKeyboardType.numberPad
        textBox3d.keyboardType = UIKeyboardType.numberPad
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(clickOff))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
        
    }
    
    //Hides keyboard and moves view down to fill whole screen
    @objc func clickOff()
    {
        view.endEditing(true)
    }
    
    
    //Retrieve the security information and store in vairables (easy to access)
    func retrieveInformation()
    {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Security")
        
        do
        {
            let information = try managedContext.fetch(fetchRequest)
            
            question = information[0].value(forKey: "question") as! String
            answer = information[0].value(forKey: "answer") as! String
            passcode = information[0].value(forKey: "passcode") as! String
            
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    
    
    
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox1aEntered(_ sender: Any)
    {
        textBox1a.isSecureTextEntry = false
        if((textBox1a.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox1a.isSecureTextEntry = true
            }
            textBox1b.becomeFirstResponder()
            textBox1a.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox1bEntered(_ sender: Any)
    {
        textBox1b.isSecureTextEntry = false
        if((textBox1b.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox1b.isSecureTextEntry = true
            }
            textBox1c.becomeFirstResponder()
            textBox1b.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox1cEntered(_ sender: Any)
    {
        textBox1c.isSecureTextEntry = false
        if((textBox1c.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox1c.isSecureTextEntry = true
            }
            textBox1d.becomeFirstResponder()
            textBox1c.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox1dEntered(_ sender: Any)
    {
        textBox1d.isSecureTextEntry = false
        if((textBox1d.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox1d.isSecureTextEntry = true
            }
            textBox2a.becomeFirstResponder()
            textBox1d.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox2aEntered(_ sender: Any)
    {
        textBox2a.isSecureTextEntry = false
        if((textBox2a.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox2a.isSecureTextEntry = true
            }
            textBox2b.becomeFirstResponder()
            textBox2a.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox2bEntered(_ sender: Any)
    {
        textBox2b.isSecureTextEntry = false
        if((textBox2b.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox2b.isSecureTextEntry = true
            }
            textBox2c.becomeFirstResponder()
            textBox2b.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox2cEntered(_ sender: Any)
    {
        textBox2c.isSecureTextEntry = false
        if((textBox2c.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox2c.isSecureTextEntry = true
            }
            textBox2d.becomeFirstResponder()
            textBox2c.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox2dEntered(_ sender: Any)
    {
        textBox2d.isSecureTextEntry = false
        if((textBox2d.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox2d.isSecureTextEntry = true
            }
            textBox3a.becomeFirstResponder()
            textBox2d.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox3aEntered(_ sender: Any)
    {
        textBox3a.isSecureTextEntry = false
        if((textBox3a.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox3a.isSecureTextEntry = true
            }
            textBox3b.becomeFirstResponder()
            textBox3a.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox3bEntered(_ sender: Any)
    {
        textBox3b.isSecureTextEntry = false
        if((textBox3b.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox3b.isSecureTextEntry = true
            }
            textBox3c.becomeFirstResponder()
            textBox3b.resignFirstResponder()
            
        }
    }
    
    //Moves the focus to the next textbox when 1 character is entered
    @IBAction func textBox3cEntered(_ sender: Any)
    {
        textBox3c.isSecureTextEntry = false
        if((textBox3c.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox3c.isSecureTextEntry = true
            }
            textBox3d.becomeFirstResponder()
            textBox3c.resignFirstResponder()
            
        }
    }
    
    @IBAction func textBox3DEntered(_ sender: Any)
    {
        textBox3d.isSecureTextEntry = false
        if((textBox3d.text)!.count == 1)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2)
            {
                self.textBox3d.isSecureTextEntry = true
            }
            
        }
        
    }
    
    
    
    
   

    
    
    @IBAction func save(_ sender: Any)
    {
        let oldPasscode = textBox1a.text! + textBox1b.text! + textBox1c.text! + textBox1d.text!
        let newPasscode1 = textBox2a.text! + textBox2b.text! + textBox2c.text! + textBox2d.text!
        let newPasscode2 = textBox3a.text! + textBox3b.text! + textBox3c.text! + textBox3d.text!
        
        if(oldPasscode == passcode && newPasscode1 == newPasscode2 && securityQuestionAnswer.text == answer && newPasscode1.count == 4)
        {
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate else {
                    return
            }
            let managedContext = appDelegate.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Security")
            
            do
            {
                let information = try managedContext.fetch(fetchRequest)
                information[0].setValue(newPasscode1, forKey: "passcode")
                
                try managedContext.save()
                
                incorrectInformation.isHidden = true
                
                var alert = UIAlertController(title: "SAVE", message: "Passcode successfully saved", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                clearBoxes()
                
            }
            catch let error as NSError
            {
                print("Could not fetch. \(error), \(error.userInfo)")
            }
        }
        else
        {
            incorrectInformation.isHidden = false
            clearBoxes()
        }
        
    }
    
    func clearBoxes()
    {
        securityQuestionAnswer.text = ""
        textBox1a.text = ""
        textBox1b.text = ""
        textBox1c.text = ""
        textBox1d.text = ""
        textBox2a.text = ""
        textBox2b.text = ""
        textBox2c.text = ""
        textBox2d.text = ""
        textBox3a.text = ""
        textBox3b.text = ""
        textBox3c.text = ""
        textBox3d.text = ""
    }
    
}


