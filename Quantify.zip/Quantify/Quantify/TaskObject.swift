//
//  TaskObject.swift
//  Quantify
//
//  Created by Amy Dowse on 26/03/2021.
//

import UIKit

class TaskObject
{
    var taskTitle: String
    var taskDescription: String
    var taskStatus: String
    var taskIndex: Int64
    
    init(titleIn: String, descriptionIn: String, statusIn: String, indexIn: Int64)
    {
        taskTitle = titleIn
        taskDescription = descriptionIn
        taskStatus = statusIn
        taskIndex = indexIn
    }
    
    
}
