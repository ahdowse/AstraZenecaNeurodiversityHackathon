//
//  SingleTaskViewController.swift
//  Quantify
//
//  Created by Amy Dowse on 30/03/2021.
//

import Foundation
import UIKit
import CoreData

class SingleTaskViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate
{
    var pickerData: [String] = [String]()
    var elementsArray = [QuantifyObject]()

    
    @IBOutlet weak var taskTitle: UITextField!
    @IBOutlet weak var taskDescription: UITextView!
    @IBOutlet weak var statusPicker: UIPickerView!
    @IBOutlet weak var quantifiedView: UICollectionView!
    
    
    override func viewDidLoad()
    {
        
        pickerData = ["Waiting", "In Progress", "Completed"]
        self.statusPicker.delegate = self
        self.statusPicker.dataSource = self
        
        var taskObject = retrieveTaskInformation()
        retrieveQuantifyInformation()
        
        taskTitle.text = taskObject?.taskTitle
        taskDescription.text = taskObject?.taskDescription
        setPicker(status: taskObject!.taskStatus)
        
        UserDefaults.standard.set(false, forKey: "AlreadyExists")
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(clickOff))
                tap.cancelsTouchesInView = false
                self.view.addGestureRecognizer(tap)

    }
    
    @objc func clickOff()
    {
        view.endEditing(true)
        self.view.frame.origin.y = 0
    }

    
    func setPicker(status:String)
    {
        if(status=="Waiting")
        {
            self.statusPicker.selectRow(0, inComponent: 0, animated: false)
        }
        else if (status=="In Progress")
        {
            self.statusPicker.selectRow(1, inComponent: 0, animated: false)
        }
        else
        {
            self.statusPicker.selectRow(2, inComponent: 0, animated: false)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return elementsArray.count
    }
    
    
    
    @objc func updateText(sender: UITextField)
    {
        elementsArray[sender.tag].quantifyData = ""+sender.text!
       
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SingleTaskCollectionViewCell", for: indexPath) as! SingleTaskCollectionViewCell
                
        cell.lblQuantifyTitle.text = elementsArray[indexPath.row].quantifyElement
        cell.txtQuantifyDetails.text = elementsArray[indexPath.row].quantifyData
        
        cell.txtQuantifyDetails.tag = indexPath.row
        cell.txtQuantifyDetails.addTarget(self, action: #selector(self.updateText),for: .editingChanged)
        
        
        return cell
    }
    
    
    
    
    func retrieveTaskInformation() -> TaskObject?
    {
        //Work done to get the saved items
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return nil
        }
    
        //Populating the tasks array
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Task")
        do
        {
            let tasks = try managedContext.fetch(fetchRequest)
            for oneTask in tasks
            {
                if(String(oneTask.value(forKey: "taskIndex")as! Int64) == UserDefaults.standard.string(forKey: "Key")!)
                {
                
                    return TaskObject(titleIn: oneTask.value(forKey: "taskTitle")as! String, descriptionIn: oneTask.value(forKey: "taskDescription")as! String, statusIn: oneTask.value(forKey: "taskStatus")as! String, indexIn: oneTask.value(forKey: "taskIndex")as! Int64)
                
                }
            }
            
            
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    
    
    
    
    
    //Gets the quantify elements from core data
    func retrieveQuantifyInformation()
    {
      

        
        elementsArray.removeAll()
        
        //Work done to get the saved items
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
    
        //Populating the tasks array
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Details")
        do
        {
            
            let tasks = try managedContext.fetch(fetchRequest)
            for oneTask in tasks
            {
                
                if(oneTask.value(forKey: "taskIndex")as? Int64 == Int64(UserDefaults.standard.string(forKey: "Key")!))
                {
                    
                    let x = QuantifyObject(indexIn: oneTask.value(forKey: "taskIndex")as! Int64, elementIn: oneTask.value(forKey: "quantifyElement")as! String, dataIn: oneTask.value(forKey: "quantifyDetails")as! String)
                
                    elementsArray.append(x)
                }
            }
            
            
            quantifiedView.reloadData()
        }
        catch let error as NSError
        {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
    }
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    @IBAction func backPressed(_ sender: Any)
    {
        let controller = storyboard!.instantiateViewController(withIdentifier: "BaseViewController") as! BaseViewController
        addChild(controller)
        view.addSubview(controller.view)
        controller.didMove(toParent: self)
        
    }
    
    @IBAction func saveButtonPressed(_ sender: Any)
    {
        saveTaskInformation()
        saveQuantifyInformation()
        
        var alert = UIAlertController(title: "SAVE", message: "Information successfully saved", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func saveTaskInformation()
    {
        var selectedValue = pickerData[statusPicker.selectedRow(inComponent: 0)]
        guard let appDelegate =
             UIApplication.shared.delegate as? AppDelegate else {
                 return
         }
         let managedContext = appDelegate.persistentContainer.viewContext
         let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Task")
         
         do
         {
             let tasks = try managedContext.fetch(fetchRequest)
             for task in tasks
             {
                 if(task.value(forKey: "taskIndex") as! Int64 == Int64(UserDefaults.standard.string(forKey: "Key")!))
                 {
                    task.setValue(taskTitle.text, forKey: "taskTitle")
                    task.setValue(taskDescription.text, forKey: "taskDescription")
                    task.setValue(selectedValue, forKey: "taskStatus")
                 }
             }
             try managedContext.save()
             
         }
         catch let error as NSError
         {
             print("Could not fetch. \(error), \(error.userInfo)")
         }
    }
    
    
    
    
    
    func saveQuantifyInformation()
    {
        
        guard let appDelegate =
             UIApplication.shared.delegate as? AppDelegate else {
                 return
         }
         let managedContext = appDelegate.persistentContainer.viewContext
         let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Details")
         
         do
         {
             let elements = try managedContext.fetch(fetchRequest)
             for element in elements
             {
                
                if(element.value(forKey: "taskIndex") as! Int64 == Int64(UserDefaults.standard.string(forKey: "Key")!))
                 {
                    for item in elementsArray
                    {
                        if(element.value(forKey: "quantifyElement") as! String == item.quantifyElement)
                        {
                            element.setValue(item.quantifyData, forKey: "quantifyDetails")
                        }
                        
                        
                    }
                 }
             }
             try managedContext.save()
             
         }
         catch let error as NSError
         {
             print("Could not fetch. \(error), \(error.userInfo)")
         }
    }
    
    
    
    
    
    
    
    
    
    
    
    @IBAction func btnAddElements(_ sender: Any)
    {
        saveTaskInformation()
        
        UserDefaults.standard.set(true, forKey: "AlreadyExists")
        
        let controller = storyboard!.instantiateViewController(withIdentifier: "BaseViewController") as! BaseViewController
        addChild(controller)
        view.addSubview(controller.view)
        controller.didMove(toParent: self)
        
    }
    
}
